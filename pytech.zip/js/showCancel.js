function showCancel()
{
    if ((document).width() == 768)
        {
            document.getElementById('cancel').style.display = 'block';
        }
}